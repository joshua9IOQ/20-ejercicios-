<?php
echo "Números pares: ";
for ($i = 2; $i <= 40; $i += 2) {
    echo $i . " ";
}

echo "<br>";

echo "Números impares: ";
for ($i = 1; $i <= 39; $i += 2) {
    echo $i . " ";
}
?>